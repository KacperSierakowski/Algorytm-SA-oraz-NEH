#include "Metal.h"



Metal::Metal()
{
}


Metal::~Metal()
{
}
