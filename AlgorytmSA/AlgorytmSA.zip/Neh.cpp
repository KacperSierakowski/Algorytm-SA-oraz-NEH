#include "Neh.h"



Kolejnosci_Cmaxy::Kolejnosci_Cmaxy()
{
	Kolejnosc = new int[LiczbaZadan];
}


Kolejnosci_Cmaxy::~Kolejnosci_Cmaxy()
{
}
