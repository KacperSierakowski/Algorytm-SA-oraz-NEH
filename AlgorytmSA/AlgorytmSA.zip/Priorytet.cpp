#include "Priorytet.h"



Priorytet::Priorytet()
{
}


Priorytet::~Priorytet()
{
}
