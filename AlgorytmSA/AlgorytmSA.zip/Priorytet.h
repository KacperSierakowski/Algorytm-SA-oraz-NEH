#pragma once
class Priorytet
{
public:

	int NumerZadania;
	int SumaPracyNaWszystkichMaszynach;

	Priorytet();
	~Priorytet();
};


