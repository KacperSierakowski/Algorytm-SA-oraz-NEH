#pragma once
class Kolejnosci_Cmaxy
{
public:

	int Cmax;
	int *Kolejnosc;
	int LiczbaZadan = 1000;

	Kolejnosci_Cmaxy();
	~Kolejnosci_Cmaxy();
};


