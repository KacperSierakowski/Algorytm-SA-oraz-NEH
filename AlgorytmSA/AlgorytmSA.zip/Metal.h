#pragma once
class Metal
{
public:

	int TemperaturaPoczatkowa;
	int WspolczynnikWychladzania;
	int rnd;


	Metal();
	~Metal();
};

