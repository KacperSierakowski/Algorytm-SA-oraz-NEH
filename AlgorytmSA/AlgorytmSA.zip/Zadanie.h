#pragma once
class Zadanie
{
public:



	int NumerZadania;
	int *CzasTrwania;
	int liczbaMaszyn = 1000;
	int SumaCzasuTrwania;



	Zadanie();
	~Zadanie();
};


