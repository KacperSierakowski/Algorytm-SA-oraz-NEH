#include "Zadanie.h"



Zadanie::Zadanie()
{

	CzasTrwania = new int[liczbaMaszyn];


}


Zadanie::~Zadanie()
{
}
